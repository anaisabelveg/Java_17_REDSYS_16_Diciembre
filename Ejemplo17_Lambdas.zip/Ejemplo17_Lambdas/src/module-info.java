/**
 * 
 */
/**
 * 
 */
module Ejemplo17_Lambdas {
}