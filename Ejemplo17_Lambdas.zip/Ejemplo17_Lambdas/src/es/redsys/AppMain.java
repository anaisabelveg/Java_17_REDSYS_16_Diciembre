package es.redsys;

import es.redsys.business.ItfzCalculadora;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear una clase anonima
		ItfzCalculadora calcu = new ItfzCalculadora() {
			
			@Override
			public double operacion(double n1, double n2) {
				return n1 + n2;
			}
		};
		System.out.println(calcu.operacion(10, 7));
		
		
		// lambda:  parametros  ->  cuerpo de la funcion
		ItfzCalculadora suma = (double n1, double n2) -> n1 + n2;
		System.out.println(suma.operacion(10, 7));
		
		// Es obligatorio mantener los parentesis de los parametros:
		//		- cuando tenemos mas de 1 parametro
		//		- cuando ponemos el tipo al parametro
		//		- cuando no se reciben parametros () -> cuerpo de la funcion
		
		// El tipo de los parametros es optativo
		ItfzCalculadora resta = (n1, n2) -> n1 - n2;
		System.out.println(resta.operacion(10, 7));
		
		// Los nombres de los parametros no tienen porque ser los mismos
		ItfzCalculadora multiplicacion = (a, b) -> a * b;
		System.out.println(multiplicacion.operacion(10, 7));
		
		
		// Si el cuerpo de la funcion tiene una sola linea, las llaves son optativas
		// Si no hay llaves, el return es implicito
		// Si ponemos llaves entonces necesitamos poner el return explicita
		ItfzCalculadora division = (n1, n2) -> {
			if (n2 == 0) {
				System.out.println("Esa division no es posible");
				return 0;					
			}
			return n1 / n2;
		};
		System.out.println(division.operacion(10, 0));
		
		
		// La inferencia de tipos tambien se puede utilizar en los lambdas
		ItfzCalculadora modulo = (var n1, var n2) -> n1 % n2;
		System.out.println(modulo.operacion(10, 7));

	}

}
