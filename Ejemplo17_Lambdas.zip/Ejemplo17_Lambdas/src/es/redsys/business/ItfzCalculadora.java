package es.redsys.business;

// Una interface funcional tiene SOLO UN método abstracto
@FunctionalInterface
public interface ItfzCalculadora {

	double operacion(double n1, double n2);
	
}
