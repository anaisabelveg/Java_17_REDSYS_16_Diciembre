package es.redsys.business;

public interface ItfzMetodos {
	
	// Novedades en Java 8:
	//	- Metodos estaticos
	//	- Metodos default
	
	public static void estatico() {
		System.out.println("Metodo estatico");
		// Desde un metodo estatico solo tengo acceso a los recursos estaticos
	}
	
	public default void defecto() {
		System.out.println("Metodo default");
	}
	
	
	// Novedad en Java 9 se recoge en Java 11(LTS)
	//	- Metodos privados
	private String mayusculas(String texto) {
		return texto.toUpperCase();
	}
	
	private String minusculas(String texto) {
		return texto.toLowerCase();
	}
	
	public default String procesarTexto(String texto) {
		// Solo desde los metodos default podemos llamar a los metodos privados
		return "Mayusculas: " + mayusculas(texto) +
				" Minusculas: " + minusculas(texto);
	}

}
