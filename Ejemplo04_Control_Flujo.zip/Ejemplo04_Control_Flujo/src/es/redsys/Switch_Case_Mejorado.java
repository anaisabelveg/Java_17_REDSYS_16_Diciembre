package es.redsys;

import java.util.Scanner;

public class Switch_Case_Mejorado {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce una letra del dia de la semana: ");
		String dia = sc.next();
		
		switch (dia) {
			case "l", "L" -> System.out.println("Es lunes");
			case "m", "M" -> System.out.println("Es martes");
			case "x", "X" -> System.out.println("Es miercoles");
			case "j", "J" -> System.out.println("Es jueves");
			case "v", "V" -> System.out.println("Es viernes");
			case "s", "S" -> System.out.println("Es sabado");
			case "d", "D" -> System.out.println("Es domingo");
			default -> System.out.println("Dia no es valido");
		}
		
		
		String cadena = switch (dia) {
			case "l", "L": {
				yield "Es lunes";
			}
			case "m", "M": {
				yield "Es martes";
			}
			case "x", "X": {
				yield "Es miercoles";
			}
			case "j", "J": {
				yield "Es jueves";
			}
			case "v", "V": {
				yield "Es viernes";
			}
			case "s", "S": {
				yield "Es sabado";
			}
			case "d", "D": {
				yield "Es domingo";
			}
			default: {
				yield "Dia no es valido";
			}
		};
		System.out.println(cadena);

	}

}
