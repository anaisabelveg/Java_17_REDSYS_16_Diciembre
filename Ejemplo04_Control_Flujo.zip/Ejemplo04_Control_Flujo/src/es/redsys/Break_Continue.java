package es.redsys;

public class Break_Continue {

	public static void main(String[] args) {
		
		// Mostrar los numeros primos del 1 al 100
		bucle_numeros:
		for(var num=1; num<=100; num++) {
			System.out.println("************** Probando numero: " + num);
			boolean esPrimo = true;
			
			// Empezamos a buscar su divisores 2 - num-1
			for(int divisor=2; divisor < num; divisor++) {
				System.out.println("Probando divisor: " + divisor + "-----------------");
				if (num % divisor == 0) {
					esPrimo = false;
					//break; // Da por finalizado el bucle de los divisores
					continue bucle_numeros; // Da por finalizada esa iteraccion y pasa a la siguiente
				}
			}
			
			if (esPrimo) {
				System.out.println(num);
			}
		}

	}

}
