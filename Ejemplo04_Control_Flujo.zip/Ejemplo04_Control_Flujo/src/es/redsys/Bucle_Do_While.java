package es.redsys;

import java.util.Scanner;

public class Bucle_Do_While {

	public static void main(String[] args) {
	
		// Metodo estatico   ->  Clase.metodo()
		int aleatorio = (int) (Math.random() * 10 + 1);
		
		// Solicitar numero al usuario dando pistas
		int numero = 0;
		Scanner sc = new Scanner(System.in);
		
		do {
			System.out.println("Introduce numero del 1 al 10: ");
			numero = sc.nextInt();
			
			if (numero > aleatorio) {
				System.out.println("Te has pasado, prueba con un numero menor");
			} else if (numero < aleatorio) {
				System.out.println("Te has quedado corto, prueba con otro numero mayor");
			} else {
				System.out.println("Enhorabuena, lo acertaste");
			}
			
		} while (aleatorio != numero);
		
		// Cerrar el recurso Scanner
		sc.close();

	}

}
