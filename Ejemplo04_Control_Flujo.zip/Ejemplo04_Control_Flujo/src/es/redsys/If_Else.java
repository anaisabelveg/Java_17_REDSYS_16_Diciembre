package es.redsys;

import java.util.Scanner;

public class If_Else {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce un numero: ");
		int numero = sc.nextInt();
		
		if (numero % 2 == 0) {
			System.out.println("El numero " + numero + " es par");
		} else {
			System.out.println("El numero " + numero + " es impar");
		}
		
		
		char dia = 'L';
		if (dia == 'l' || dia == 'L')
			System.out.println("Es lunes");
		else if (dia == 'm' || dia == 'M')
			System.out.println("Es martes");
		else if (dia == 'x' || dia == 'X')
			System.out.println("Es miercoles");
		else if (dia == 'j' || dia == 'J')
			System.out.println("Es jueves");
		else if (dia == 'v' || dia == 'V')
			System.out.println("Es viernes");
		else if (dia == 's' || dia == 'S')
			System.out.println("Es sabado");
		else if (dia == 'd' || dia == 'D')
			System.out.println("Es domingo");
		else
			System.out.println("Dia no valido");
		
		
		// Operador ternario
		int num1 = 7;
		int num2 = 32;
		int resultado = (num1 > num2) ? num1 : num2;
		System.out.println(resultado);
		
		System.out.println("El mayor es " + ((num1 > num2) ? num1 : num2) );

	}

}
