package es.redsys;

import java.util.Scanner;

public class Bucle_While {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce password: ");
		String pw = sc.next();
		
		while (! "curso".equals(pw)) {
			System.out.println("No has acertado, vuelve a intentarlo");
			System.out.println("Introduce password: ");
			pw = sc.next();
		}
		
		System.out.println("PW Correcto");
		
		sc.close();

	}

}
