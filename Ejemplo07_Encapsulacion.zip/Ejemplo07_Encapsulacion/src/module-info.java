/**
 * 
 */
/**
 * 
 */
module Ejemplo07_Encapsulacion {
}