package es.redsys;

import es.redsys.models.Fecha;
import es.redsys.models.FechaEncapsulada;

public class AppMain {

	public static void main(String[] args) {
		
		Fecha fecha = new Fecha();
		fecha.dia = 17;
		fecha.mes = 12;
		fecha.anyo = 2024;
		
		fecha.mostrar();
		
		Fecha fechaErronea = new Fecha();
		fechaErronea.dia = 69565;
		fechaErronea.mes = 4212154;
		fechaErronea.anyo = -266;
		
		fechaErronea.mostrar();
		
		
		FechaEncapsulada fEncapsulada = new FechaEncapsulada();
		fEncapsulada.setDia(868757);
		fEncapsulada.setMes(876);
		fEncapsulada.setAnyo(-15433);
		
		fEncapsulada.mostrar();
		
		FechaEncapsulada fEncapsulada2 = new FechaEncapsulada();
		fEncapsulada2.setDia(17);
		fEncapsulada2.setMes(12);
		fEncapsulada2.setAnyo(2024);
		
		fEncapsulada2.mostrar();

	}

}
