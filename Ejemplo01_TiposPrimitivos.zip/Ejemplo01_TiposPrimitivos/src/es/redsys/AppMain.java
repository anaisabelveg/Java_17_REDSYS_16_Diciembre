package es.redsys;

// Las clases deben comenzar por letra mayuscula
public class AppMain {

	// Marca el punto de entrada a la aplicacion
	public static void main(String[] args) {
		
		/*
		 * Ejemplo para mostrar los tipos primitivos
		 * */
		
		// Numericos enteros
		byte numByte = 8;				// 8 bits
		short numShort = 250;   		// 16 bits
		int numInt = 67788;     		// 32 bits   (defecto)
		long numLong = 6754534576788L;	// 64 bits   sufijo l o L
		
		// Numericos reales
		float numFloat = 3.1416F;		// 32 bits	 sufijo F o f
		double numDouble = 3.1416;		// 64 bits   (defecto)
		
		// Booleanos: true o false
		boolean incidencia = true;
		
		// Caracteres: 'caracter'
		char letra = 'l';
		
		
		// String es una clase, no es un tipo primitivo
		// La clase se escribe primera letra con mayuscula.
		// Las cadenas de texto van entre comillas dobles   "cadenas"
		String saludo = "Bienvenidos al curso de Java";
		
		// Mostrar informacion en la consola
		// syso + ctrl + space
		System.out.println(saludo);
		
		System.out.println("Numero entero: " + numInt);
		
		// Palabra reservada
		// String goto = 'hola';
	}

}
