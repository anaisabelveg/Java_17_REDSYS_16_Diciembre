package es.redsys;

public class EjemploAserciones {

	public static void main(String[] args) {
		
		int numero = -8;
		
		// Si esta comprobacion se hiciera con if-else
		// ese codigo se queda y siempre se ejecuta
		// mientas que las aserciones las puedes activar o no.
		
		// Las aserciones por defecto estan deshabilitadas. para habilitarlas
		// java -ea EjemploAserciones
		
		// Afirmo que numero > 0:
		//		si es cierto no hace nada
		// 		si es false lanza un AssertionError
		assert (numero > 0) : "Error, el numero deberia ser mayor que 0";

	}

}
