package es.redsys;

public class MultiExceptions {

	public static void main(String[] args) {
		
		String[] datos = {"1", "dos", "3", "4"};
		int suma = 0;
		
		for(int i=0; i<=datos.length; i++) {
			try {
				int num = Integer.parseInt(datos[i]);
				suma += num;
			} catch (NumberFormatException | ArrayIndexOutOfBoundsException ex) {
				if (ex.getClass().getName().equals("java.lang.NumberFormatException")){
					System.out.println("Valor no convertible a entero: " + ex.getMessage());
				} else {
					System.out.println("Nos hemos salido de los indices del array");
				}
			}
		}
		System.out.println("Suma: " + suma);

	}

}
