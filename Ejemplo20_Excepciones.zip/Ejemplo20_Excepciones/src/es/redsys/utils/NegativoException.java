package es.redsys.utils;

/**
 * Las excepciones en Java pueden ser de 2 tipos:
 * 		checked: me obliga a manejar la excepcion (Excepcion)
 * 		unchecked: no me obliga a manejar la excepcion (RuntimeException)
 */

public class NegativoException extends RuntimeException{
	
	public NegativoException(String mensaje) {
		super(mensaje);
	}

}
