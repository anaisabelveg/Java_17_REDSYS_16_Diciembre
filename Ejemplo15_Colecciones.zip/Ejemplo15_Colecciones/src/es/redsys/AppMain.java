package es.redsys;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		
		// Set -> NO permite duplicados, NO garantiza el orden de entrada
		// List -> SI perm ite duplicados, SI garantiza el orden de entrada
		
		Set numeros = new HashSet();
		numeros.add(1);
		numeros.add("dos");
		numeros.add(new Integer(70));
		numeros.add(Integer.valueOf(65));
		numeros.add("dos");   // los duplicados los ignora
		
		System.out.println(numeros);
		
		for (Object item : numeros) {
			System.out.println(item);
		}
		
		
		List nombres = new ArrayList();
		nombres.add("Luis");
		nombres.add("Maria");
		nombres.add("Pedro");
		nombres.add("Luis");
		nombres.add("Juan");
		
		System.out.println(nombres);
		
		Iterator it = nombres.listIterator();
		while (it.hasNext()) {
			Object item = it.next();	
			System.out.println(item);
		}
		
		
		// A partir de Java 5 utilizamos tipos genericos para limitar el tipo de datos de la coleccion
		// Los tipos genericos deben ser clases, nunca tipos primitivos
		// A partir de Java 7 no es necesario ponerlo en el constructor, aunque se recomienda dejar <>
		Set<Integer> numeros2 = new HashSet<>();
		numeros2.add(1);
		//numeros2.add("dos");   ERROR de compilacion porque no es Integer
		numeros2.add(new Integer(70));
		numeros2.add(Integer.valueOf(65));
		
		for (Integer num : numeros2) {
			System.out.println(num);
		}
		
		List<String> nombres2 = new ArrayList<>();
		nombres2.add("Luis");
		nombres2.add("Maria");
		nombres2.add("Pedro");
		nombres2.add("Luis");
		nombres2.add("Juan");
		
		for (String nombre : nombres2) {
			System.out.println(nombre.toUpperCase());
		}
		
		
		
		// Map -> elementos formados por clave=valor
		// NO garantiza el orden de entrada
		// Las claves no se pueden repetir, si se repite se sobreescribe el valor
		// Los valores si se pueden repetir
		Map<String, Double> alumnos = new HashMap<>();
		alumnos.put("Juan", 6.3);
		alumnos.put("Maria", 8.9);
		alumnos.put("Pedro", 3.5);
		alumnos.put("Pedro", 5.0);
		
		System.out.println(alumnos);
		
		System.out.println("Nota de Maria: " + alumnos.get("Maria"));
		System.out.println("Items: " + alumnos.entrySet());
		System.out.println("Nombre de los alumnos: " + alumnos.keySet());
		System.out.println("Notas de los alumnos: " + alumnos.values());
		
		
		
		
		
		
		
		
		

	}

}
