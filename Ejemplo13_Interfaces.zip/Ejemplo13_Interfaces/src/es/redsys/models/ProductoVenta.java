package es.redsys.models;

public interface ProductoVenta {
	
	// No existen las variables en las interfaces, son CONSTANTES
	// double precio;
	
	// Declarar los metodos
	// Por defecto, todos los metodos seran publicos y abstractos
	public abstract void setPrecio(double precio);
	public void setCodigo(String codigo);
	
	abstract double getPrecio();
	String getCodigo();

}
