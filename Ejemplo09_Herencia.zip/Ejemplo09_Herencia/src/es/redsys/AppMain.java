package es.redsys;

import es.redsys.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		
		// Clase variable = new constructor();
		Empleado empleado = new Empleado("Juan", 37, 1, 58_000);
		
		System.out.println(empleado.getNombre());
		System.out.println(empleado.getSueldo());
		
		// Internamente llama al metodo toString()
		System.out.println(empleado);
		System.out.println(empleado.toString());
		
		// Con tipos primitivos el valor se guarda en la variable
		// El operador == compara el contenido de las variables
		int num1 = 8;
		int num2 = 8;
		System.out.println("Son iguales los numeros? " + (num1 == num2));  // true  8 == 8
		
		// Las variables de tipo clase almacenan es la referencia al objeto
		Empleado e1 = new Empleado("Juan", 37, 1, 58_000);
		Empleado e2 = new Empleado("Juan", 37, 1, 58_000);
		System.out.println("Son iguales los empleados? " + (e1 == e2));  // false  #1234 == #5678
		
		// Para comparar objetos se utiliza el metodo equals
		System.out.println("Son iguales los empleados? " + (e1.equals(e2)) );
		
		// Los String para optimizar memoria se guardan en un pool
		String nombre1 = "Pedro";  // Si es la primera vez crea la cadena en el pool
		String nombre2 = "Pedro";  // como la cadena ya existe devuelve la referencia de la cadena.
		System.out.println("Son iguales los nombres? " + (nombre1 == nombre2)); // true
		
		// De esta forma estoy forzando a crear nuevos objetos
		// y no reutilizarlos del pool
		String nom1 = new String("Pedro");
		String nom2 = new String("Pedro");
		System.out.println("Son iguales los nombres? " + (nom1 == nom2)); // false
		
		// En la clase String ya esta el equals sobreescrito
		System.out.println("Son iguales los nombres? " + (nom1.equals(nom2))); // true

	}

}
