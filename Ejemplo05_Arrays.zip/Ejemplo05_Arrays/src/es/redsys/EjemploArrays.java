package es.redsys;

import java.util.Arrays;

public class EjemploArrays {

	public static void main(String[] args) {
		
		// Declarar una variable de tipo array
		int numeros[];
		String [] nombres;
		char[] letras;
		
		// Cuidado con las declaraciones multiples
		int a[], b, c, d;   // a es array y el resto variables enteras
		int [] e, f, g, h;  // todas son arrays
		
		// Crear el array
		numeros = new int[4];  // Es obligatorio darle un tamaño (longitud del array)
		
		// Asignar valores en el array
		numeros[0] = 6;  // 0 es el indice del array
		numeros[1] = 3;
		numeros[2] = 9;
		numeros[3] = 1;
		// numeros[4] = 6;  // no existe este indice -> ArrayIndexOutBoundsExceptions
		
		
		// Todo en 1. Declaro, creo y lleno de valores el array
		int numeros2[] = {6,3,9,1};
		int numeros3[] = new int[]{6,3,9,1};
		
		// De esta forma no podemos utilizar inferencia de tipos
		// var numeros4[] = {6,3,9,1};
		// var numeros4 = {6,3,9,1};
		
		// Pero si le decimos que es un array de enteros si funciona, pero hay que quitar los corchetes
		var numeros5 = new int[]{6,3,9,1};

		
		// Recorrer un array: for tradicional y for-each
		for (int i=0; i<numeros.length; i++ ) {
			System.out.println(numeros[i]);
		}
		
		for (int num : numeros) {
			System.out.println(num);
		}
		
		// La clase Arrays del paquete java.util ahi teneis metodos utiles
		
		
		// En Java, los arrays no son redimensionales
		// Si se queda pequeño, creamos uno mas grande y hacemos volcado de datos
		int[] grande = new int[10];
		System.arraycopy(numeros, 0, grande, 0, numeros.length);
		
		System.out.println(grande);
		System.out.println(Arrays.toString(grande));

	}

}
