package es.redsys;

import java.util.Arrays;

public class EjemploMatrices {

	public static void main(String[] args) {
		
		// Matriz cuadrada
		int matriz[][] = new int[3][2];   // [filas][columnas]
		
		matriz[0][0] = 1;
		matriz[0][1] = 2;
		matriz[1][0] = 3;
		matriz[1][1] = 4;
		matriz[2][0] = 5;
		matriz[2][1] = 6;

		int matriz2[][] = { {1,2}, {3,4}, {5,6} };
		
		
		// Matriz no cuadrada
		int matriz3[][] = new int[2][];   // Es obligatorio poner el numero de filas
		matriz3[0] = new int[5];
		matriz3[1] = new int[2];
		
		matriz3[0][0] = 1;
		matriz3[0][1] = 2;
		matriz3[0][2] = 3;
		matriz3[0][3] = 4;
		matriz3[0][4] = 5;
		matriz3[1][0] = 6;
		matriz3[1][1] = 7;
		
		
		// Recorrer con for tradicional
		for (int fila=0; fila < matriz3.length; fila++) {
			for (int columna=0; columna < matriz3[fila].length; columna++) {
				System.out.print(matriz3[fila][columna] + " ");
			}
			System.out.println();
		}
		
		// Recorrer con for-each
		for (int[] fila : matriz3) {
			for (int numero : fila) {
				System.out.print(numero + " ");
			}
			System.out.println();
		}
		
		System.out.println(matriz3);
		System.out.println(Arrays.toString(matriz3));
		System.out.println(Arrays.deepToString(matriz3));
	}

}
