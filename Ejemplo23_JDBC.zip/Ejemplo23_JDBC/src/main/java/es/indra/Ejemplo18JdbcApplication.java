package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.persistence.ProductosDAO;

@SpringBootApplication
public class Ejemplo18JdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo18JdbcApplication.class, args);
		
		ProductosDAO dao = new ProductosDAO();
		dao.consultarTodos().forEach(System.out::println);
		
		System.out.println("Encontrado " + dao.buscarProducto(3));
	}

}
