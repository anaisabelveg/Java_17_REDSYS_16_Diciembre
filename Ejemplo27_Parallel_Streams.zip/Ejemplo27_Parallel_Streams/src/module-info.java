/**
 * 
 */
/**
 * 
 */
module Ejemplo27_Parallel_Streams {
}