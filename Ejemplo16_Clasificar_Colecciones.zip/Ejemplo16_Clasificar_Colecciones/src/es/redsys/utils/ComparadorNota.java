package es.redsys.utils;

import java.util.Comparator;

import es.redsys.models.Alumno;

public class ComparadorNota implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		// retorna 1 o cualquier positivo si la primera instancia es mayor que la segunda
		// retorna -1 o cualquier negativo si la primera  la instancia es menor que la segunda
		// retorna 0 si son iguales
		if (alum1.getNota() > alum2.getNota()) {
			return 1;
		} else if (alum1.getNota() < alum2.getNota()) {
			return -1;
		} else {
			return 0;
		}	
	}

}
