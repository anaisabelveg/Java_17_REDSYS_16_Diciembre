package es.redsys.models;

public class AlumnoComparable implements Comparable<AlumnoComparable>{
	
	private int numAlumno;
	private String nombre;
	private double nota;
	
	public AlumnoComparable() {
		// TODO Auto-generated constructor stub
	}

	public AlumnoComparable(int numAlumno, String nombre, double nota) {
		super();
		this.numAlumno = numAlumno;
		this.nombre = nombre;
		this.nota = nota;
	}
	
	@Override
	public int compareTo(AlumnoComparable otro) {
		// retorna 1 o cualquier positivo si la instancia es mayor que el otro alumno
		// retorna -1 o cualquier negativo si la instancia es menor que el otro alumno
		// retorna 0 si son iguales
		if (this.nota > otro.getNota()) {
			return 1;
		} else if (this.nota < otro.getNota()) {
			return -1;
		} else {
			return 0;
		}	
	}
	

	public int getNumAlumno() {
		return numAlumno;
	}

	public void setNumAlumno(int numAlumno) {
		this.numAlumno = numAlumno;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Alumno [numAlumno=" + numAlumno + ", nombre=" + nombre + ", nota=" + nota + "]";
	}

	
	

}
