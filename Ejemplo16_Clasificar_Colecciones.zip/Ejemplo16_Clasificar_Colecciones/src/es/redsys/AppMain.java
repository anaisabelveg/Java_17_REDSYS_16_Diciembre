package es.redsys;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import es.redsys.models.Alumno;
import es.redsys.models.AlumnoComparable;
import es.redsys.utils.ComparadorNota;

public class AppMain {

	public static void main(String[] args) {
		
//		Set<AlumnoComparable> alumnos = new TreeSet<AlumnoComparable>();
//		
//		alumnos.add(new AlumnoComparable(1, "Juan", 6.9));
//		alumnos.add(new AlumnoComparable(2, "Maria", 8.9));
//		alumnos.add(new AlumnoComparable(3, "Pedro", 7.2));
//		alumnos.add(new AlumnoComparable(4, "Jorge", 9.5));
//		alumnos.add(new AlumnoComparable(5, "Luis", 3.4));
//		alumnos.add(new AlumnoComparable(6, "Sofia", 2.5));
//		
//		for (AlumnoComparable alumno : alumnos) {
//			System.out.println(alumno);
//		}
		
		// Crear un arbol de alumnos clasificados por nota
		// Set<Alumno> alumnos = new TreeSet<Alumno>(new ComparadorNota());
		
		// Crear un arbol de alumnos clasificados por nombre
		Set<Alumno> alumnos = new TreeSet<Alumno>(new Comparator<Alumno>() {
			@Override
			public int compare(Alumno o1, Alumno o2) {
				return o1.getNombre().compareTo(o2.getNombre());
			}
		});
		alumnos.add(new Alumno(1, "Juan", 6.9));
		alumnos.add(new Alumno(2, "Maria", 8.9));
		alumnos.add(new Alumno(3, "Pedro", 7.2));
		alumnos.add(new Alumno(4, "Jorge", 9.5));
		alumnos.add(new Alumno(5, "Luis", 3.4));
		alumnos.add(new Alumno(6, "Sofia", 2.5));
		
		for (Alumno alumno : alumnos) {
			System.out.println(alumno);
		}
		
		// El coste de recorrer un arbol es exponencial entonces no se recomienda
		// La solucion es pasarlo a una lista
		List<Alumno> lista = new ArrayList<Alumno>(alumnos);

	}

}
