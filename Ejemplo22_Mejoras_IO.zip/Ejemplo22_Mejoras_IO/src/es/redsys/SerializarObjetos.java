package es.redsys;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import es.redsys.models.Empleado;

public class SerializarObjetos {

	public static void main(String[] args) {
		
		
		try (FileInputStream fichero = new FileInputStream("empleado.ser");
			 ObjectInputStream inputStream = new ObjectInputStream(fichero)	){
			
			// Deserializacion
			Empleado empleado = (Empleado) inputStream.readObject();
			empleado.mostrarDetalle();
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
