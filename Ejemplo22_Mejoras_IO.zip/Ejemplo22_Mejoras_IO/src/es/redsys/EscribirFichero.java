package es.redsys;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class EscribirFichero {

	public static void main(String[] args) {
		
		// Los recursos que se abren dentro de los parentesis del bloque try
		// y ademas son AutoCloseables, se cierran solos
		// No es necesario llamar al metodo close
		try (FileWriter fichero = new FileWriter("datos.txt");
			 BufferedWriter bWriter = new BufferedWriter(fichero)){
			
			// Escribir contenido en el fichero
			bWriter.write("Hola");
			bWriter.write("\n");
			bWriter.write("Como estas?\n");
			bWriter.write("Hoy es viernes");
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
