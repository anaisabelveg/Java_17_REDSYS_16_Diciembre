package es.redsys;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class LeerFichero {

	public static void main(String[] args) {
		
		try (FileReader fichero = new FileReader("datos.txt");
			 BufferedReader bReader = new BufferedReader(fichero)	){
			
			bReader.lines()
				.map(linea -> linea.toUpperCase())
				.forEach(System.out::println);
			
			Path path = Paths.get("datos.txt");
			List<String> lista = Files.readAllLines(path);
			System.out.println(lista);
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
