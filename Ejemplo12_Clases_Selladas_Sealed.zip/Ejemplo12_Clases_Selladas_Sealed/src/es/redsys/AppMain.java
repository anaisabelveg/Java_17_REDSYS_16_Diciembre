package es.redsys;

import es.redsys.models.Figura;
import es.redsys.models.Rectangulo;

public class AppMain {

	public static void main(String[] args) {
		
		// Una clase abstracta se puede utilizar como tipo pero no se puede instanciar
		//Figura figura = new Figura();
		
		// Si me permite instanciar una clase abstracta si en ese momento implemento el metodo abstracto
		// Clase anonima
		Figura figura = new Figura(10,20) {
			
			@Override
			public double calcularArea() {
				// TODO Auto-generated method stub
				return 0;
			}
		};
		
		// Polimorfismo
		Figura rectangulo = new Rectangulo(10, 20, 100, 40);
		System.out.println(rectangulo.calcularArea());

	}

}
