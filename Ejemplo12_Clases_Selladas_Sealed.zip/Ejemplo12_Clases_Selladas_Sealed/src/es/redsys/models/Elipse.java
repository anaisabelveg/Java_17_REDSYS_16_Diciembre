package es.redsys.models;

//Cuando se hereda de una clase sellada (sealed), la subclase tambien esta sellada
//y debemos de quitar el sellado
public non-sealed class Elipse extends Circulo{
	
	private double radio2;
	
	public Elipse() {
		// TODO Auto-generated constructor stub
	}

	public Elipse(int x, int y, double radio, double radio2) {
		super(x, y, radio);
		this.radio2 = radio2;
	}
	
	@Override
	public double calcularArea() {
		return Math.PI * getRadio() * radio2;
	}

	public double getRadio2() {
		return radio2;
	}

	public void setRadio2(double radio2) {
		this.radio2 = radio2;
	}

	@Override
	public String toString() {
		return "Elipse [radio2=" + radio2 + ", toString()=" + super.toString() + "]";
	}
	
	

}
