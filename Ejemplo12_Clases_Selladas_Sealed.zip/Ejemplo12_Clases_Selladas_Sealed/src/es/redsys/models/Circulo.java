package es.redsys.models;

// Cuando se hereda de una clase sellada (sealed), la subclase tambien esta sellada
// y debemos de quitar el sellado o decir a quien permitimos heredar de la clase Circulo
public sealed class Circulo extends Figura permits Elipse{

	private double radio;

	public Circulo() {
		// TODO Auto-generated constructor stub
	}

	public Circulo(int x, int y, double radio) {
		super(x, y);
		this.radio = radio;
	}

	@Override
	public double calcularArea() {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}

	@Override
	public String toString() {
		return "Circulo [radio=" + radio + ", toString()=" + super.toString() + "]";
	}
	
}
