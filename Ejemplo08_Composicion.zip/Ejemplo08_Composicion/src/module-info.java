/**
 * 
 */
/**
 * 
 */
module Ejemplo06_Clases_Objetos {
}