package es.redsys;

import es.redsys.models.Direccion;
import es.redsys.models.Empleado;

public class AppMain {
	
	public static void main(String[] args) {
		
		// Crear un objeto o instancia de Empleado
		Empleado empleado =  new Empleado();  // new contructor
		empleado.numEmpleado = 1;
		empleado.nombre = "Juan";
		empleado.sueldo = 52_000;
		empleado.direccion = new Direccion("Mayor", 5, "Madrid");
		
		empleado.mostrarDetalle();
		System.out.println(empleado.verNombre());
		
		empleado.cambiarSueldo(56_000);
		empleado.mostrarDetalle();
		
		
		Empleado empleado2 = new Empleado(2, "Maria", 59_000, new Direccion("Diagonal", 138, "Barcelona"));
		empleado2.mostrarDetalle();
	}

}
