package es.redsys;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import es.redsys.models.Alumno;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear un arbol de alumnos clasificados por nota
		Set<Alumno> alumnos = new TreeSet<Alumno>(Comparator.comparingDouble(Alumno::getNota));
		
		// Crear un arbol de alumnos clasificados por nombre
		//Comparator<Alumno> porNombre = (o1, o2) -> o1.getNombre().compareTo(o2.getNombre());
		//Set<Alumno> alumnos = new TreeSet<Alumno>(porNombre);
		alumnos.add(new Alumno(1, "Juan", 6.9));
		alumnos.add(new Alumno(2, "Maria", 8.9));
		alumnos.add(new Alumno(3, "Pedro", 7.2));
		alumnos.add(new Alumno(4, "Jorge", 9.5));
		alumnos.add(new Alumno(5, "Luis", 3.4));
		alumnos.add(new Alumno(6, "Sofia", 2.5));
		
		for (Alumno alumno : alumnos) {
			System.out.println(alumno);
		}
		System.out.println("-".repeat(30));
		
		// El coste de recorrer un arbol es exponencial entonces no se recomienda
		// La solucion es pasarlo a una lista
		List<Alumno> lista = new ArrayList<Alumno>(alumnos);
		
		// Ordenar la lista por nota descendente
		lista.sort(Comparator.comparingDouble(Alumno::getNota).reversed());
		lista.forEach(item -> System.out.println(item));
		System.out.println("*".repeat(30));
		
		// Ordenar la lista por numero de alumno
		lista.sort(Comparator.comparingInt(Alumno::getNumAlumno));
		lista.forEach(item -> System.out.println(item));
		System.out.println("-".repeat(30));
		
		// Otra forma de Ordenar la lista por numero de alumno
		lista.sort((alum1, alum2) -> alum1.getNumAlumno() - alum2.getNumAlumno());
		lista.forEach(item -> System.out.println(item));
		System.out.println("-".repeat(30));
		
		// Otra forma de Ordenar la lista por numero de alumno descendente
		lista.sort((alum1, alum2) -> alum2.getNumAlumno() - alum1.getNumAlumno());
		lista.forEach(item -> System.out.println(item));
		System.out.println("-".repeat(30));
		
		// Ordenar por el nombre
		lista.sort(Comparator.comparing(Alumno::getNombre));
		lista.forEach(System.out::println);
		System.out.println("-".repeat(30));
		
		// Ordenar por el nombre de forma descendente
		lista.sort(Comparator.comparing(Alumno::getNombre).reversed());
		lista.forEach(System.out::println);
		System.out.println("-".repeat(30));

	}

}
