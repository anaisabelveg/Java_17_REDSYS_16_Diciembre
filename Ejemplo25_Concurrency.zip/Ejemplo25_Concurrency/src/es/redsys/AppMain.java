package es.redsys;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class AppMain {

	public static void main(String[] args) {
		
		// Ejemplo de 5 hilos para procesar 10 tareas
		
		
		// Crear un pool de 5 hilos
		ExecutorService executorService = Executors.newFixedThreadPool(5);
		
		
		// Crear las 10 tareas y enviarlas al pool
		for (int i=1; i<=10; i++) {
			final int idTarea = i;
			executorService.execute( () -> {
				System.out.println("Tarea " + idTarea + " iniciada por " + Thread.currentThread().getName());
				
				// Codigo a ejecutar
				try {
					Thread.sleep(3_000); // Parar el hilo 3 segundos
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				System.out.println("Tarea " + idTarea + " completada por " + Thread.currentThread().getName());
			});
		}
		
		// Si apago el pool aqui tendre 5 tareas ejecutadas y 5 sin ejecutar
//		List lista =   executorService.shutdownNow();
//		lista.forEach(System.out::println);
		
		
		// Esperar a que terminen todas las tareas o esperar 10 segundos
		try {
			if (executorService.awaitTermination(10, TimeUnit.SECONDS)) {
				// Apagar el pool
				List lista =   executorService.shutdownNow();
				
				// Se han ejecutado todas las tareas y la lista esta vacia
				lista.forEach(System.out::println);
			}
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
		
		System.out.println("Todas las tareas completadas");

	}

}
