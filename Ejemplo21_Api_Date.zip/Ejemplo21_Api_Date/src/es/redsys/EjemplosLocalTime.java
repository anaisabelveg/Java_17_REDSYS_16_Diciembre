package es.redsys;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class EjemplosLocalTime {

	public static void main(String[] args) {
		
		// Hora actual
		LocalTime ahora = LocalTime.now();
		System.out.println(ahora);

		// Solo horas:minutos
		System.out.println(ahora.truncatedTo(ChronoUnit.MINUTES));

		// Cuantas horas nos quedan de clase
		LocalTime fin = LocalTime.of(14, 00);
		System.out.println(ahora.until(fin, ChronoUnit.HOURS));

		// Cuantos minutos nos quedan de clase
		System.out.println(ahora.until(fin, ChronoUnit.MINUTES));

		// Transformar la hora a segundos
		System.out.println(ahora.toSecondOfDay() + " segundos");

		// Transformar la hora a minutos
		System.out.println(ahora.toSecondOfDay() / 60 + " minutos");

		// Transformar la hora a horas
		System.out.println(ahora.toSecondOfDay() / 60 / 60 + " horas");

	}

}
