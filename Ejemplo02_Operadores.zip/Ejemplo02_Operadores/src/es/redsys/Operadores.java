package es.redsys;

public class Operadores {
	
	// En variables globales, en propiedades no se permite la inferencia de tipos
	// Solo en variables locales
	// var prueba = 4;

	public static void main(String[] args) {
		
		// Novedades Java 11 - LTS (8,11,17,21)
		// Inferencia de tipos
		var num1 = 7.0;
		var num2 = 2;
		
		// Operadores aritmeticos
		// syso + ctrl + space
		System.out.println("Suma: " + (num1 + num2));
		System.out.println("Suma: " + num1 + num2);
		System.out.println("Resta: " + (num1 - num2));
		System.out.println("Multiplicacion: " + (num1 * num2));
		System.out.println("Division: " + (num1 / num2));
		System.out.println("Resto: " + (num1 % num2));
		
		
		// Incrementos y decrementos
		num2++;   // num2 = num2 + 1;
		num2--;   // num2 = num2 - 1;
		
		int resultado = num2++;    // post-incremento    1º asigna, 2º incrementa   resultado=2, num2=3
		resultado = ++num2;        // pre-incremento     1º incrementa, 2º asigna   resultado=3, num2=3
		
		
		// Operadores de comparacion
		boolean mayor = num1 > num2;   // true
		
		
		// Operadores logicos
		System.out.println( (num1 == 7) && (num2 > 0) );
		
		
		// Operadores de asignacion compuestos
		num1 += 5;    // num1 = num1 + 5;
		num1 -= 5;    // num1 = num1 - 5;
		num1 *= 5;    // num1 = num1 * 5;
		num1 /= 5;    // num1 = num1 / 5;
		num1 %= 5;    // num1 = num1 % 5;

	}

}
