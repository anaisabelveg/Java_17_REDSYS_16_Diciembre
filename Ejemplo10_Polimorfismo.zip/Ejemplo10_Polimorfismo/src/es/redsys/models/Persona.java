package es.redsys.models;

import java.util.Objects;

// Si el compilador ve que no heredamos de ninguna clase añade extends Object
// public class Persona extends Object{
public class Persona{
	
	private String nombre;
	private int edad;
	
	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(String nombre, int edad) {
		super();  // Invocando al constructor de la superclase 
		this.nombre = nombre;
		this.edad = edad;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	@Override
	public String toString() {
		return "nombre=" + nombre + ", edad=" + edad;
	}

	@Override
	public int hashCode() {
		return Objects.hash(edad, nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)   // Si es la misma instancia
			return true;
		if (obj == null)   // comparar un objeto contra otro que no existe
			return false;
		if (getClass() != obj.getClass())  // si las clases de los objetos son distintas
			return false;
		Persona other = (Persona) obj; // casting
		return edad == other.edad && Objects.equals(nombre, other.nombre);
	}
	
	

}
