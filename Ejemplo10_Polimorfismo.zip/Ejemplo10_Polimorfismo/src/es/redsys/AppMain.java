package es.redsys;

import es.redsys.models.Empleado;
import es.redsys.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		
		// Clase variable = new constructor();
		Empleado empleado = new Empleado("Juan", 37, 1, 58_000);
		
		
		// Una vez creada la instancia de Empleado no cambia
		// Lo que cambia es la forma de verla.
		
		// Si la variable que tiene la referencia del objeto es de tipo Empleado, vemos los recursos de Empleado
		empleado.getNombre();
		empleado.getNumEmpleado();
		empleado.getSueldo();
		empleado.getClass();
		
		
		// Cambiar la visibilidad del objeto a Persona
		Persona persona = empleado;
		persona.getClass();
		persona.getNombre();
		persona.getEdad();
		//persona.getSueldo(); no es accesible porque el sueldo esta en la clase Empleado
		
		
		// Cambiar la visibilidad del objeto a Object
		Object object = empleado;
		object.getClass();
		
		
		// Cambiar la visibilidad de la clase mas general a la mas especifica
		// Necesitamos hacer casting
		Empleado empleado2 = (Empleado) object;
		
		
		// Para que sirve el polimorfismo?
		//     - para tratar un grupo de objetos de la misma forma  (p.e. nominas(Empleado))
		//     - equals(Object)  me posibilita el poder comparar diferentes objetos Empleado, Coche, Factura
		
	}

}
