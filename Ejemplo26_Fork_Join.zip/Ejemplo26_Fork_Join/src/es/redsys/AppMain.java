package es.redsys;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;
import java.util.stream.LongStream;

public class AppMain {
	
	/*
	 * Fork/Join (divide y venceras) es un framework para mejorar las ejecuciones en paralelo
	 * sacandole el maximo partido a los nuvles del microprocesador,
	 * 
	 * Divide una tarea grande en subtareas y al final combina el resultado de ambas subtareas
	 * para emitir el resultado final.
	 * 
	 * Clases o componentes principales:
	 * 		ForkJoinPool: El pool donde gestionamos las tareas.
	 * 		ForkJoinTask: Clase abstracta que define la tarea a ejecutar.
	 * 		RecursiveAction: Subclase de ForkJoinTask para tareas sin retorno
	 * 		RecursiveTask: Subclase de ForkJoinTask para tareas con retorno
	 * 
	 * Funcionamiento:
	 * 		1.- Crear la tarea a ejecutar con RecursiveAction o RecursiveTask
	 * 		2.- Se envia la tarea al pool ForkJoinPool
	 * 		3.- Dividir la tarea grande en subtareas ("operacion Fork")
	 * 		4.- Todas las subtareas se ejecutan en paralelo
	 * 		5.- Los resultados de cada subtarea se combinan ("operacion Join")
	 * */

	public static void main(String[] args) {
		// Sumar los numeros del 1 al 500_000_000
		LongStream stLong = LongStream.rangeClosed(1, 500_000_000);
		long[] arrayNumeros = stLong.toArray();
		
		// Crear el pool
		ForkJoinPool pool = ForkJoinPool.commonPool();
		
		// Crear la tarea
		TareaSumar tarea = new TareaSumar(arrayNumeros, 0, arrayNumeros.length);
		
		// Ejecutar la tarea enviandola al pool y recogiendo el resultado.
		long tiempoInicio = System.currentTimeMillis();
		long resultado = pool.invoke(tarea);
		System.out.println("Resultado: " + resultado);
		long tiempoFinal = System.currentTimeMillis();
		System.out.println("Tiempo invertido: " + (tiempoFinal - tiempoInicio) + " mseg");
	}
	
	
	static class TareaSumar extends RecursiveTask<Long>{
		
		private long[] numeros;
		private int inicio;
		private int fin;
			
		public TareaSumar(long[] numeros, int inicio, int fin) {
			super();
			this.numeros = numeros;
			this.inicio = inicio;
			this.fin = fin;
		}

		@Override
		protected Long compute() {
			// Probar cuanto tiempo tarda en sumar todos los numeros sin FORK
			// 433 mseg
//			long suma = 0;
//			
//			for (int i = inicio; i<fin; i++) {
//				suma += numeros[i];
//			}
//			
//			return suma;
			
			// Operacion Fork
			// Sumar por bloques de 100_000
			// Si el tamaño de la subtarea es menor de 100_000 lo suma
			// Si es mayor lo divido en 2 subtareas
			// 298 mseg
			if (fin - inicio <= 100_000) {
				long suma = 0;
				for (int i = inicio; i<fin; i++) {
					suma += numeros[i];
				}
				return suma;
			} else {
				int mitad = (inicio + fin) / 2;
				TareaSumar subTarea1 = new TareaSumar(numeros, inicio, mitad);
				TareaSumar subTarea2 = new TareaSumar(numeros, mitad, fin);
				
				// Fork de las subtareas
				subTarea1.fork();
				subTarea2.fork();
				
				// Join de los resultados
				return subTarea1.join() + subTarea2.join();
			}
		}
		
	}

}
