/**
 * 
 */
/**
 * 
 */
module Ejemplo19_Streams {
}